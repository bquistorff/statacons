# Introductory Example for `statacons`

_version 1.1.0_

This zip file contains all the code and data required to replicate the Introductory Example in the `statacons` paper.

To replicate the Introductory Example, follow these steps:

1. Install python, scons, pystatacons and statacons as needed

  a. (if needed) Follow the installation instructions on the repository or the Installation Guide in the paper (Appendix A) to install python, scons and pystatacons

  b. (optional) Follow the Installation Guide (Appendix A) of the paper to install `statacons`. This is optional because the zip-file contains all the `statacons` code.

  c. Check that `statacons` is installed and working with any or all of the following from the Stata prompt:
      ```
        which statacons
        python which SCons
        python which pystatacons
        statacons --show-config
        do debugging-checklist.do
      ```

  d. (if needed or desired) Configure `statacons` using `config_user.ini` and `config_project.ini`

2. Unzip `stataconsIntro.zip` into the desired location. To use the `statacons.ado` packaged with the zip file, `do profile.do` from within Stata. Otherwise, Stata will find `statacons.ado` where you have installed it according to your `adopath`.

3. Follow the Introductory Example in the paper.
