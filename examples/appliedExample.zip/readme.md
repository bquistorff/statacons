# Applied Example: Shumway and Wilson 2021

This zip file contains code from the Applied Example (Shumway and Wilson 2021) in the `statacons` paper.

This is *not* a comprehensive replication archive. Rather, we provide complete files that we reference in the paper but could not fit in the paper itself. The code here consists mostly of `statacons`-related files, e.g., SConstructs, configuration files, etc. We have included  do-files from the Sun and Abraham (2021) event study which are relevant to concepts discussed in the paper (separation of concerns, parallel builds). 

References
------

Shumway, Clayson, and Riley Wilson. 2021. “Workplace Disruptions, Judge Caseloads, and Judge Decisions: Evidence from SSA Judicial Corps Retirements.” Working Paper. https://go.ncsu.edu/shumway.wilson.judges.

Sun, Liyang, and Sarah Abraham. 2021. “Estimating Dynamic Treatment Effects in Event Studies with Heterogeneous Treatment Effects.” Journal of Econometrics, 225 (2): 175–99. https://doi.org/10.1016/j.jeconom.2020.09.006.
